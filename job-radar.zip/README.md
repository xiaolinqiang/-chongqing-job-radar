# 重庆职位雷达 · iOS PWA

一个面向单一用户的重庆大公司职位雷达。手机端是静态 PWA，职位发现与评分由每日自动化脚本完成。

## 当前第一版已经具备

- iPhone Safari 可添加到主屏幕；
- 今日推荐 / 职位库 / 我的机会 / 设置四个页面；
- 0–100 可解释匹配评分与「直接投 / 值得冲 / 观察」；
- 收藏、已投递、面试中、不感兴趣等本地状态；
- 重庆 Base、大公司、专业 IC 岗偏好；
- 30 家目标大公司配置；
- BOSS、猎聘、智联、51job、LinkedIn、拉勾等公开招聘结果的发现入口；
- 每日 GitHub Actions 自动刷新并部署到 GitHub Pages；
- 无搜索 API 密钥时使用 `data/seed_jobs.json`，保证 App 仍可运行。

## 本地预览

```bash
python scripts/update_jobs.py --no-search
python scripts/serve.py
```

浏览器打开 `http://127.0.0.1:8080`。

## 开启真正的每日联网更新

第一版的联网发现 Provider 使用 Serper 搜索 API。密钥只存放在 GitHub Actions Secret，不进入 iPhone 或仓库文件。

1. 创建 GitHub 仓库并上传本项目。
2. Repository Settings → Secrets and variables → Actions，新建 `SERPER_API_KEY`。
3. Repository Settings → Pages → Source 选择 **GitHub Actions**。
4. 合并/推送到默认分支。
5. `.github/workflows/update-jobs.yml` 每天北京时间 08:15 自动运行，也可在 Actions 手动运行。
6. 工作流完成后，GitHub Pages 会提供 HTTPS 地址。

> 没有 `SERPER_API_KEY` 时，定时任务仍会运行和部署，但只会重新发布内置的已核实职位；不会发现新的公网岗位。

## iPhone 安装

在 iPhone Safari 打开部署后的 HTTPS 地址：分享 → **添加到主屏幕** → 添加。之后从主屏幕图标启动即可进入独立 Web App。

## 数据与隐私

- 职位来源链接保留在职位卡中；
- 不自动登录招聘网站，不绕过验证码或反爬；
- 不保存身份证、手机号等个人敏感信息；
- 第一版收藏/投递状态保存在当前 iPhone 的 `localStorage`，暂未做跨设备云同步；
- 搜索密钥仅由 GitHub Actions 读取。

## 目录

- `public/`：可直接部署的 PWA
- `radar/`：职位标准化、去重、评分
- `scripts/update_jobs.py`：每日职位生成器
- `config/target_companies.json`：30 家目标公司
- `config/preferences.json`：默认筛选画像
- `data/seed_jobs.json`：首批核实职位
- `.github/workflows/update-jobs.yml`：定时刷新 + Pages 部署
