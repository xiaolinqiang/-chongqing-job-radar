export const defaultPreferences = {
  minSalary: 12,
  preferredSalary: 15,
  companyTiers: ['S','A'],
  showHidden: false,
  allowManagement: false,
  allowSales: false
};

function text(job) {
  return `${job.company ?? ''} ${job.title ?? ''} ${job.description ?? ''}`.toLowerCase();
}

export function filterJobs(jobs, filters = {}, statuses = {}) {
  const query = (filters.query ?? '').trim().toLowerCase();
  const minSalary = Number(filters.minSalary ?? 0);
  const showHidden = Boolean(filters.showHidden);
  const companyTier = filters.companyTier ?? '';
  const source = filters.source ?? '';
  const tier = filters.tier ?? '';

  return jobs.filter(job => {
    if (statuses[job.id] === 'disliked') return false;
    if (!showHidden && Number(job.score ?? 0) < 60) return false;
    if (query && !text(job).includes(query)) return false;
    if (minSalary && Number(job.salary_max_k ?? 0) < minSalary) return false;
    if (companyTier && job.company_tier !== companyTier) return false;
    if (tier && job.tier !== tier) return false;
    if (source && !(job.sources ?? []).some(item => item.name === source)) return false;
    return true;
  });
}

export function sortJobs(jobs, sortBy = 'score') {
  const cloned = [...jobs];
  if (sortBy === 'published') {
    return cloned.sort((a,b) => {
      const dateCompare = String(b.published_at ?? '').localeCompare(String(a.published_at ?? ''));
      if (dateCompare !== 0) return dateCompare;
      return Number(b.score ?? 0) - Number(a.score ?? 0);
    });
  }
  if (sortBy === 'salary') {
    return cloned.sort((a,b) => Number(b.salary_max_k ?? 0) - Number(a.salary_max_k ?? 0));
  }
  return cloned.sort((a,b) => Number(b.score ?? 0) - Number(a.score ?? 0));
}

export function dashboardStats(jobs, statuses = {}, nowISO = new Date().toISOString()) {
  const today = String(nowISO).slice(0,10);
  return {
    today: jobs.filter(job => String(job.published_at ?? '').slice(0,10) === today || String(job.discovered_at ?? '').slice(0,10) === today).length,
    highMatch: jobs.filter(job => Number(job.score ?? 0) >= 85).length,
    worthShot: jobs.filter(job => Number(job.score ?? 0) >= 72 && Number(job.score ?? 0) < 85).length,
    favorites: Object.values(statuses).filter(status => status === 'favorite').length
  };
}

export function statusLabel(status) {
  return ({favorite:'已收藏', applied:'已投递', interviewing:'面试中', ended:'已结束', disliked:'不感兴趣'})[status] ?? '';
}
