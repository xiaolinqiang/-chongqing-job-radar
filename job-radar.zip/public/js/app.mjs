import { dashboardStats, defaultPreferences, filterJobs, sortJobs, statusLabel } from './app-core.mjs';

const STATUS_KEY = 'jobRadar.statuses.v1';
const PREF_KEY = 'jobRadar.preferences.v1';
const DEFAULT_COMPANIES = ['赛力斯集团','长安汽车','华为','龙湖集团','德勤','字节跳动','腾讯','美团','京东'];

const state = {
  jobs: [],
  updatedAt: '',
  statuses: loadJSON(STATUS_KEY, {}),
  preferences: loadJSON(PREF_KEY, {...defaultPreferences, preferredCompanies: DEFAULT_COMPANIES}),
  activeView: 'today',
  applicationFilter: 'favorite',
  filters: {query:'', tier:'', companyTier:'', sortBy:'score'}
};

function loadJSON(key, fallback){
  try { return JSON.parse(localStorage.getItem(key)) ?? fallback; }
  catch { return fallback; }
}
function saveJSON(key, value){ localStorage.setItem(key, JSON.stringify(value)); }
function escapeHTML(value=''){ return String(value).replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c])); }
function dateLabel(iso){
  if(!iso) return '发布时间未注明';
  const d = new Date(iso.length === 10 ? `${iso}T00:00:00+08:00` : iso);
  if(Number.isNaN(d.getTime())) return iso;
  return new Intl.DateTimeFormat('zh-CN',{month:'numeric',day:'numeric'}).format(d);
}
function fullDateLabel(){ return new Intl.DateTimeFormat('zh-CN',{month:'long',day:'numeric',weekday:'short'}).format(new Date()); }
function updatedLabel(){
  if(!state.updatedAt) return '职位库更新时间未知';
  const d = new Date(state.updatedAt);
  return `职位库更新于 ${new Intl.DateTimeFormat('zh-CN',{month:'numeric',day:'numeric',hour:'2-digit',minute:'2-digit'}).format(d)}`;
}

async function loadJobs({force=false}={}){
  const button = document.querySelector('#refresh-button');
  button?.classList.add('is-spinning');
  try{
    const suffix = force ? `?t=${Date.now()}` : '';
    const response = await fetch(`./data/jobs.json${suffix}`, {cache: force ? 'reload' : 'default'});
    if(!response.ok) throw new Error(`HTTP ${response.status}`);
    const payload = await response.json();
    state.jobs = payload.jobs ?? [];
    state.updatedAt = payload.updated_at ?? '';
    renderAll();
  }catch(error){
    document.querySelector('#job-list').innerHTML = emptyState('暂时读不到职位库','检查网络后再刷新；已安装的 PWA 仍可读取上一次缓存。');
    console.error(error);
  }finally{ button?.classList.remove('is-spinning'); }
}

function renderAll(){
  renderToday();
  renderJobs();
  renderApplications();
  renderSettings();
}

function renderToday(){
  document.querySelector('#today-date').textContent = `${fullDateLabel()} · ${updatedLabel()}`;
  const visible = filterJobs(state.jobs, {showHidden:state.preferences.showHidden}, state.statuses);
  const sorted = sortJobs(visible,'score');
  const stats = dashboardStats(state.jobs,state.statuses,new Date().toISOString());
  document.querySelector('#summary-focus').textContent = stats.highMatch || sorted.filter(j=>j.score>=72).length || 0;
  document.querySelector('#summary-copy').textContent = stats.highMatch ? '个高匹配机会，优先看前 3 个' : '个值得进一步看的机会';
  document.querySelector('#stats-grid').innerHTML = [
    ['今日新增',stats.today],['直接投',stats.highMatch],['值得冲',stats.worthShot],['已收藏',stats.favorites]
  ].map(([label,value])=>`<div class="stat-item"><strong>${value}</strong><span>${label}</span></div>`).join('');
  const primary = sorted.filter(j=>j.score>=72).slice(0,5);
  renderJobList(document.querySelector('#job-list'), primary.length ? primary : sorted.slice(0,5));
}

function renderJobs(){
  const filters = {
    query:state.filters.query,
    tier:state.filters.tier,
    companyTier:state.filters.companyTier,
    showHidden:state.preferences.showHidden
  };
  const jobs = sortJobs(filterJobs(state.jobs,filters,state.statuses),state.filters.sortBy);
  document.querySelector('#jobs-result-meta').textContent = `共 ${jobs.length} 个职位 · 默认隐藏“不感兴趣”和低匹配岗位`;
  renderJobList(document.querySelector('#all-job-list'),jobs);
}

function renderApplications(){
  document.querySelectorAll('[data-status-filter]').forEach(btn=>btn.classList.toggle('is-active',btn.dataset.statusFilter===state.applicationFilter));
  const jobs = state.jobs.filter(job=>state.statuses[job.id]===state.applicationFilter);
  const labels = {favorite:'还没有收藏职位',applied:'还没有记录已投递',interviewing:'还没有面试中的机会',ended:'还没有已结束的机会'};
  if(!jobs.length){ document.querySelector('#application-job-list').innerHTML = emptyState(labels[state.applicationFilter],'在职位卡片上操作后会自动出现在这里。'); return; }
  renderJobList(document.querySelector('#application-job-list'),sortJobs(jobs,'published'));
}

function jobCard(job){
  const template = document.querySelector('#job-card-template');
  const node = template.content.firstElementChild.cloneNode(true);
  node.dataset.jobId = job.id;
  node.querySelector('.company-name').textContent = job.company;
  node.querySelector('.company-tier').textContent = `${job.company_tier || '—'}级`;
  node.querySelector('.job-title').textContent = job.title;
  node.querySelector('.job-meta').textContent = [job.location,job.salary,job.experience,job.education,dateLabel(job.published_at)].filter(Boolean).join(' · ');
  node.querySelector('.score-value').textContent = job.score ?? '—';
  const tagRow = node.querySelector('.tag-row');
  const tags = [
    [job.tier,'primary'],[job.salary,'salary'],[job.sources?.[0]?.name || '公开来源','']
  ];
  tagRow.innerHTML = tags.filter(([x])=>x).map(([label,cls])=>`<span class="tag ${cls}">${escapeHTML(label)}</span>`).join('');
  node.querySelector('.comparison').textContent = job.comparison || '建议结合完整 JD 再判断。';
  const reasons = job.reasons?.length ? job.reasons : ['岗位信息仍需进一步核实'];
  const gaps = job.gaps?.length ? job.gaps : ['暂无明显硬伤，重点确认工作边界'];
  node.querySelector('.reason-list').innerHTML = reasons.map(x=>`<li>${escapeHTML(x)}</li>`).join('');
  node.querySelector('.gap-list').innerHTML = gaps.map(x=>`<li>${escapeHTML(x)}</li>`).join('');
  node.querySelector('.source-row').innerHTML = (job.sources ?? []).filter(s=>s.url).map(s=>`<a class="source-link" href="${escapeHTML(s.url)}" target="_blank" rel="noopener">查看 ${escapeHTML(s.name)} JD ↗</a>`).join('') || '<span class="subtle">暂无原始链接</span>';

  const details = node.querySelector('.job-details');
  const expand = node.querySelector('.expand-button');
  expand.addEventListener('click',()=>{ details.hidden=!details.hidden; expand.textContent=details.hidden?'看分析':'收起'; });
  const favorite = node.querySelector('.favorite-button');
  const applied = node.querySelector('.applied-button');
  const pipeline = node.querySelector('.pipeline-select');
  syncActionButtons(job.id,favorite,applied);
  if (['applied','interviewing','ended'].includes(state.statuses[job.id])) pipeline.value = state.statuses[job.id];
  favorite.addEventListener('click',()=>setStatus(job.id,state.statuses[job.id]==='favorite'?null:'favorite'));
  applied.addEventListener('click',()=>setStatus(job.id,'applied'));
  pipeline.addEventListener('change',()=>{ if(pipeline.value) setStatus(job.id,pipeline.value); });
  node.querySelector('.dislike-button').addEventListener('click',()=>setStatus(job.id,'disliked'));
  return node;
}

function syncActionButtons(id,favorite,applied){
  const status=state.statuses[id];
  favorite.classList.toggle('is-active',status==='favorite');
  favorite.textContent=status==='favorite'?'已收藏':'收藏';
  applied.classList.toggle('is-active',['applied','interviewing'].includes(status));
  applied.textContent=status==='interviewing'?'面试中':status==='applied'?'已投递':'已投递';
}
function renderJobList(container,jobs){
  container.innerHTML='';
  if(!jobs.length){container.innerHTML=emptyState('暂时没有符合条件的职位','可以调整筛选，或者等下一次职位库更新。');return;}
  const fragment=document.createDocumentFragment();
  jobs.forEach(job=>fragment.append(jobCard(job)));
  container.append(fragment);
}
function emptyState(title,copy){return `<div class="empty-state"><strong>${escapeHTML(title)}</strong><p>${escapeHTML(copy)}</p></div>`;}
function setStatus(id,status){
  if(status) state.statuses[id]=status; else delete state.statuses[id];
  saveJSON(STATUS_KEY,state.statuses);renderAll();
}

function renderSettings(){
  const p=state.preferences;
  document.querySelector('#minimum-salary').value=p.minSalary ?? 12;
  document.querySelector('#preferred-salary').value=p.preferredSalary ?? 15;
  document.querySelector('#allow-management').checked=Boolean(p.allowManagement);
  document.querySelector('#allow-sales').checked=Boolean(p.allowSales);
  document.querySelector('#show-hidden').checked=Boolean(p.showHidden);
  document.querySelector('#preferred-companies').value=(p.preferredCompanies ?? DEFAULT_COMPANIES).join('\n');
  syncSalaryDisplay();
}
function syncSalaryDisplay(){
  document.querySelector('#salary-display').textContent=`${document.querySelector('#minimum-salary').value}K / ${document.querySelector('#preferred-salary').value}K+`;
}

function navigate(view){
  state.activeView=view;
  document.querySelectorAll('.view').forEach(el=>el.classList.toggle('is-active',el.dataset.view===view));
  document.querySelectorAll('[data-nav]').forEach(el=>el.classList.toggle('is-active',el.dataset.nav===view));
  window.scrollTo({top:0,behavior:'instant'});
}

document.querySelector('#bottom-nav').addEventListener('click',e=>{const btn=e.target.closest('[data-nav]');if(btn)navigate(btn.dataset.nav);});
document.addEventListener('click',e=>{const btn=e.target.closest('[data-nav-target]');if(btn)navigate(btn.dataset.navTarget);});
document.querySelector('#refresh-button').addEventListener('click',()=>loadJobs({force:true}));
document.querySelector('#job-search').addEventListener('input',e=>{state.filters.query=e.target.value;renderJobs();});
document.querySelector('#filter-tier').addEventListener('change',e=>{state.filters.tier=e.target.value;renderJobs();});
document.querySelector('#filter-company').addEventListener('change',e=>{state.filters.companyTier=e.target.value;renderJobs();});
document.querySelector('#sort-by').addEventListener('change',e=>{state.filters.sortBy=e.target.value;renderJobs();});
document.querySelector('#status-tabs').addEventListener('click',e=>{const btn=e.target.closest('[data-status-filter]');if(btn){state.applicationFilter=btn.dataset.statusFilter;renderApplications();}});
document.querySelector('#minimum-salary').addEventListener('input',syncSalaryDisplay);
document.querySelector('#preferred-salary').addEventListener('input',syncSalaryDisplay);
document.querySelector('#settings-form').addEventListener('submit',e=>{
  e.preventDefault();
  state.preferences={
    ...state.preferences,
    minSalary:Number(document.querySelector('#minimum-salary').value),
    preferredSalary:Number(document.querySelector('#preferred-salary').value),
    allowManagement:document.querySelector('#allow-management').checked,
    allowSales:document.querySelector('#allow-sales').checked,
    showHidden:document.querySelector('#show-hidden').checked,
    preferredCompanies:document.querySelector('#preferred-companies').value.split('\n').map(x=>x.trim()).filter(Boolean)
  };
  saveJSON(PREF_KEY,state.preferences);renderAll();
  const feedback=document.querySelector('#save-feedback');feedback.textContent='已保存到这台 iPhone';setTimeout(()=>feedback.textContent='',1800);
});

loadJobs();

if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => navigator.serviceWorker.register('./sw.js').catch(console.error));
}
