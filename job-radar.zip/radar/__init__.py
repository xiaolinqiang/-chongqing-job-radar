"""Chongqing Job Radar domain package."""
