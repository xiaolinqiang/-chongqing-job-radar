"""Discovery normalization, deduplication, and JSON publication."""
from __future__ import annotations

import hashlib
import json
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path


def _clean(value) -> str:
    return " ".join(str(value or "").strip().split())


def stable_job_id(company: str, title: str, location: str) -> str:
    raw = "|".join((_clean(company).lower(), _clean(title).lower(), _clean(location).lower()))
    return hashlib.sha1(raw.encode("utf-8")).hexdigest()[:14]


def normalize_search_result(result: dict) -> dict:
    company = _clean(result.get("company"))
    title = _clean(result.get("title"))
    location = _clean(result.get("location")) or "重庆"
    source = _clean(result.get("source")) or "公开招聘页面"
    source_url = _clean(result.get("source_url"))
    description = _clean(result.get("description"))
    normalized = {
        "id": stable_job_id(company, title, location),
        "company": company,
        "company_tier": _clean(result.get("company_tier")) or "C",
        "title": title,
        "location": location,
        "salary": _clean(result.get("salary")) or "面议",
        "experience": _clean(result.get("experience")) or "未注明",
        "education": _clean(result.get("education")) or "未注明",
        "description": description,
        "published_at": _clean(result.get("published_at")),
        "discovered_at": _clean(result.get("discovered_at")),
        "is_outsourcing": bool(result.get("is_outsourcing", False)),
        "sources": [{"name": source, "url": source_url}],
    }
    return normalized


def dedupe_jobs(jobs: list[dict]) -> list[dict]:
    merged: dict[str, dict] = {}
    for job in jobs:
        job_id = job.get("id") or stable_job_id(job.get("company", ""), job.get("title", ""), job.get("location", ""))
        current = merged.get(job_id)
        if current is None:
            merged[job_id] = deepcopy(job)
            continue

        current_sources = {(s.get("name"), s.get("url")) for s in current.get("sources", [])}
        for source in job.get("sources", []):
            key = (source.get("name"), source.get("url"))
            if key not in current_sources:
                current.setdefault("sources", []).append(source)
                current_sources.add(key)

        if len(job.get("description", "")) > len(current.get("description", "")):
            current["description"] = job.get("description", "")
        for field in ("salary", "experience", "education", "published_at", "company_tier"):
            if (not current.get(field) or current.get(field) in {"面议", "未注明", "C"}) and job.get(field):
                current[field] = job[field]
    return list(merged.values())


def publish_jobs(jobs: list[dict], path: str | Path, updated_at: str | None = None) -> None:
    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    if updated_at is None:
        updated_at = datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")
    ordered = sorted(jobs, key=lambda job: (job.get("score", 0), job.get("published_at", "")), reverse=True)
    payload = {"updated_at": updated_at, "count": len(ordered), "jobs": ordered}
    output.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
