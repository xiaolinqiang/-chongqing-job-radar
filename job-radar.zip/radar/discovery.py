"""Discovery normalization, deduplication, and JSON publication."""
from __future__ import annotations

import hashlib
import json
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlparse, parse_qs


def _clean(value) -> str:
    return " ".join(str(value or "").strip().split())




PORTAL_DETAIL_RULES = {
    "liepin.com": (r"^/job/\d+\.shtml$",),
    "zhaopin.com": (r"^/jobs/[^/]+\.htm$",),
    "zhipin.com": (r"^/job_detail/[^/]+\.html$",),
    "51job.com": (r"/[^/]+/\d+\.html$", r"/job/"),
    "linkedin.com": (r"/jobs/view/",),
    "lagou.com": (r"/jobs/\d+\.html$",),
}

PSEUDO_TITLE_PATTERNS = (
    r"怎么样$",
    r"好不好$",
    r"工资待遇",
    r"薪资待遇",
    r"招聘信息$",
    r"职位列表$",
    r"岗位列表$",
    r"人才招聘$",
    r"招聘岗位$",
    r"^20\d{2}年.+岗位$",
    r"^.+岗位招聘$",
)


def is_direct_job_url(url: str) -> bool:
    """Return True only when a URL looks like a concrete job-detail page.

    For known recruiting portals we use strict path rules so search/list pages are
    never presented to the user as a JD link. For company career sites we allow
    common job-detail URL shapes or explicit job/position ids.
    """
    value = _clean(url)
    if not value:
        return False
    parsed = urlparse(value)
    host = parsed.netloc.lower().split(":")[0]
    path = parsed.path or "/"
    query = parse_qs(parsed.query)

    import re
    for domain, patterns in PORTAL_DETAIL_RULES.items():
        if domain in host:
            return any(re.search(pattern, path, flags=re.IGNORECASE) for pattern in patterns)

    generic_path_patterns = (
        r"/(job|jobs|position|positions|vacancy|vacancies)/[^/]+",
        r"/(career|careers|recruit|recruitment)/.+/(job|position)/?",
    )
    if any(re.search(pattern, path, flags=re.IGNORECASE) for pattern in generic_path_patterns):
        return True
    id_keys = {"jobid", "job_id", "positionid", "position_id", "vacancyid", "vacancy_id"}
    return any(key.lower() in id_keys and any(str(v).strip() for v in values) for key, values in query.items())


def is_pseudo_job_title(title: str) -> bool:
    """Identify search/aggregation/article titles that are not actual job names."""
    import re
    value = _clean(title)
    if not value:
        return True
    return any(re.search(pattern, value, flags=re.IGNORECASE) for pattern in PSEUDO_TITLE_PATTERNS)


def stable_job_id(company: str, title: str, location: str) -> str:
    raw = "|".join((_clean(company).lower(), _clean(title).lower(), _clean(location).lower()))
    return hashlib.sha1(raw.encode("utf-8")).hexdigest()[:14]


def normalize_search_result(result: dict) -> dict:
    company = _clean(result.get("company"))
    title = _clean(result.get("title"))
    location = _clean(result.get("location")) or "重庆"
    source = _clean(result.get("source")) or "公开招聘页面"
    source_url = _clean(result.get("source_url"))
    description = _clean(result.get("description"))
    normalized = {
        "id": stable_job_id(company, title, location),
        "company": company,
        "company_tier": _clean(result.get("company_tier")) or "C",
        "title": title,
        "location": location,
        "salary": _clean(result.get("salary")) or "面议",
        "experience": _clean(result.get("experience")) or "未注明",
        "education": _clean(result.get("education")) or "未注明",
        "description": description,
        "published_at": _clean(result.get("published_at")),
        "discovered_at": _clean(result.get("discovered_at")),
        "is_outsourcing": bool(result.get("is_outsourcing", False)),
        "sources": [{"name": source, "url": source_url}],
    }
    return normalized


def dedupe_jobs(jobs: list[dict]) -> list[dict]:
    merged: dict[str, dict] = {}
    for job in jobs:
        job_id = job.get("id") or stable_job_id(job.get("company", ""), job.get("title", ""), job.get("location", ""))
        current = merged.get(job_id)
        if current is None:
            merged[job_id] = deepcopy(job)
            continue

        current_sources = {(s.get("name"), s.get("url")) for s in current.get("sources", [])}
        for source in job.get("sources", []):
            key = (source.get("name"), source.get("url"))
            if key not in current_sources:
                current.setdefault("sources", []).append(source)
                current_sources.add(key)

        if len(job.get("description", "")) > len(current.get("description", "")):
            current["description"] = job.get("description", "")
        for field in ("salary", "experience", "education", "published_at", "company_tier"):
            if (not current.get(field) or current.get(field) in {"面议", "未注明", "C"}) and job.get(field):
                current[field] = job[field]
    return list(merged.values())


def publish_jobs(jobs: list[dict], path: str | Path, updated_at: str | None = None) -> None:
    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    if updated_at is None:
        updated_at = datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")
    ordered = sorted(jobs, key=lambda job: (job.get("score", 0), job.get("published_at", "")), reverse=True)
    payload = {"updated_at": updated_at, "count": len(ordered), "jobs": ordered}
    output.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
