"""Shared lightweight model helpers for Job Radar."""
from typing import TypedDict


class JobSource(TypedDict):
    name: str
    url: str


class JobRecord(TypedDict, total=False):
    id: str
    company: str
    company_tier: str
    title: str
    location: str
    salary: str
    experience: str
    education: str
    description: str
    published_at: str
    discovered_at: str
    is_outsourcing: bool
    sources: list[JobSource]
    score: int
    tier: str
    reasons: list[str]
    gaps: list[str]
    comparison: str
