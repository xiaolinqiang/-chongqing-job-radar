"""Explainable scoring for the private Chongqing job radar."""
from __future__ import annotations

import re


def normalize_salary(text: str):
    if not text:
        return (None, None, None)
    cleaned = text.lower().replace(" ", "")
    months_match = re.search(r"[·x×*]?([1-2][0-9])薪", cleaned)
    months = int(months_match.group(1)) if months_match else None
    range_match = re.search(r"(\d+(?:\.\d+)?)[-~—–](\d+(?:\.\d+)?)k", cleaned)
    if range_match:
        return (round(float(range_match.group(1))), round(float(range_match.group(2))), months)
    single_match = re.search(r"(\d+(?:\.\d+)?)k", cleaned)
    if single_match:
        value = round(float(single_match.group(1)))
        return (value, value, months)
    return (None, None, months)


def recommendation_tier(score: int) -> str:
    if score >= 85:
        return "直接投"
    if score >= 72:
        return "值得冲"
    if score >= 60:
        return "观察"
    return "隐藏"


def _contains_any(text: str, keywords: list[str]) -> list[str]:
    return [kw for kw in keywords if kw and kw.lower() in text.lower()]


def score_job(job: dict, preferences: dict) -> dict:
    title = str(job.get("title", ""))
    description = str(job.get("description", ""))
    text = f"{title} {description}"
    reasons: list[str] = []
    gaps: list[str] = []

    # 1) Company platform: 25
    tier_points = {"S": 25, "A": 22, "B": 15, "C": 7}
    company_tier = str(job.get("company_tier", "C")).upper()
    company_score = tier_points.get(company_tier, 7)
    if company_score >= 22:
        reasons.append("公司平台强，履历品牌价值高")
    elif company_score <= 7:
        gaps.append("公司平台相对有限")

    # 2) Long-term role value: 25
    target_keywords = preferences.get("target_keywords", [])
    matched = _contains_any(text, target_keywords)
    durable_terms = ["指标", "体系", "预算", "forecast", "目标管理", "经营分析", "运营分析", "数据治理", "数据应用", "bi", "市场研究", "商业分析"]
    durable_matches = _contains_any(text, durable_terms)
    role_score = min(25, 10 + min(len(set(matched)), 3) * 4 + min(len(set(durable_matches)), 3))
    if matched:
        reasons.append("岗位方向与现有经营/数据分析能力匹配")
    if durable_matches:
        reasons.append("包含可长期积累的指标、经营或数据应用能力")

    # 3) Current experience match: 20
    transferable_terms = ["目标", "预算", "经营", "数据", "分析", "指标", "监控", "预测", "复盘", "bi", "用户", "市场"]
    transfer_matches = _contains_any(text, transferable_terms)
    experience_score = min(20, 8 + len(set(transfer_matches)) * 2)
    if experience_score >= 16:
        reasons.append("现有工作经历可直接迁移，不属于从零转行")
    elif experience_score <= 10:
        gaps.append("与当前经历的直接迁移点偏少")

    # 4) Salary uplift: 15
    salary_min, salary_max, salary_months = normalize_salary(str(job.get("salary", "")))
    preferred = preferences.get("preferred_salary_k", 15)
    minimum = preferences.get("minimum_salary_k", 12)
    current = preferences.get("current_salary_k", 9)
    if salary_min is None:
        salary_score = 6
        gaps.append("薪资未明确，需要面试确认")
    elif salary_min >= preferred:
        salary_score = 15
        reasons.append("薪资较当前水平有明显提升空间")
    elif salary_max is not None and salary_max >= preferred and salary_min >= minimum:
        salary_score = 12
        reasons.append("薪资区间具备达到目标水平的可能")
    elif salary_max is not None and salary_max > current:
        salary_score = 7
        gaps.append("薪资提升有限，需争取区间上沿")
    else:
        salary_score = 2
        gaps.append("薪资相对当前工作缺乏明显提升")

    # 5) Work style: 10
    style_score = 10
    management_terms = ["团队管理", "带领团队", "管理团队", "负责人", "总监", "经理"]
    sales_terms = ["销售拓展", "销售代表", "电话销售", "业务拓展", "商务拓展", "招商主管", "开发客户"]
    has_management = bool(_contains_any(text, management_terms)) and "不带团队" not in text
    has_sales = bool(_contains_any(text, sales_terms))
    exclude_hits = _contains_any(text, preferences.get("exclude_keywords", []))
    if has_management and not preferences.get("allow_management", False):
        style_score -= 5
        gaps.append("岗位包含明显团队管理责任")
    if (has_sales or exclude_hits) and not preferences.get("allow_sales", False):
        style_score -= 6
        gaps.append("岗位销售/拓展属性偏强")
    if job.get("is_outsourcing"):
        style_score -= 4
        gaps.append("存在外包或驻场属性")
    style_score = max(0, style_score)

    # 6) Chongqing/location: 5
    location = str(job.get("location", ""))
    location_score = 5 if "重庆" in location else 0
    if location_score:
        reasons.append("Base 重庆")
    else:
        gaps.append("非重庆 Base")

    score = company_score + role_score + experience_score + salary_score + style_score + location_score

    # Hard/strong penalties from the product rules.
    if location_score == 0:
        score = min(score, 45)
    if (has_sales or exclude_hits) and not preferences.get("allow_sales", False):
        score = min(score, 55)
    if salary_max is not None and salary_max < minimum and company_tier not in {"S", "A"}:
        score = min(score, 58)
    if job.get("is_outsourcing"):
        score = min(score, 65)

    score = max(0, min(100, int(round(score))))
    tier = recommendation_tier(score)

    if salary_min is not None and salary_min >= preferred and company_tier in {"S", "A"}:
        comparison = "相比当前工作：平台与薪资均具备升级潜力"
    elif company_tier in {"S", "A"}:
        comparison = "相比当前工作：平台有价值，重点确认薪资与工作边界"
    else:
        comparison = "相比当前工作：需确认是否构成真正的职业升级"

    reason_priority = ["薪资", "平台", "匹配", "长期", "迁移", "Base"]
    gap_priority = ["销售", "管理", "外包", "薪资", "平台", "迁移", "非重庆"]

    def _prioritized(items, keys):
        ranked = sorted(
            enumerate(items),
            key=lambda pair: min(
                [keys.index(k) for k in keys if k in pair[1]] or [len(keys)]
            ),
        )
        return [item for _, item in ranked[:3]]

    return {
        "score": score,
        "tier": tier,
        "reasons": _prioritized(reasons, reason_priority),
        "gaps": _prioritized(gaps, gap_priority),
        "comparison": comparison,
        "salary_min_k": salary_min,
        "salary_max_k": salary_max,
        "salary_months": salary_months,
        "components": {
            "company": company_score,
            "role_value": role_score,
            "experience": experience_score,
            "salary": salary_score,
            "work_style": style_score,
            "location": location_score,
        },
    }
