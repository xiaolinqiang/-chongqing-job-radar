#!/usr/bin/env python3
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
import os

ROOT = Path(__file__).resolve().parents[1] / "public"
os.chdir(ROOT)
server = ThreadingHTTPServer(("127.0.0.1", 8080), SimpleHTTPRequestHandler)
print("Job Radar preview: http://127.0.0.1:8080")
try:
    server.serve_forever()
except KeyboardInterrupt:
    pass
finally:
    server.server_close()
