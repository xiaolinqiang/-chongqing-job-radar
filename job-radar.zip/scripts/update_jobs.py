#!/usr/bin/env python3
"""Build the public job feed from curated fixtures plus optional public search discovery."""
from __future__ import annotations

import argparse
import json
import os
import re
import sys
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlparse

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from radar.discovery import dedupe_jobs, is_direct_job_url, is_pseudo_job_title, normalize_search_result, publish_jobs
from radar.scoring import score_job

PORTAL_DOMAINS = {
    "zhipin.com": "BOSS直聘",
    "liepin.com": "猎聘",
    "zhaopin.com": "智联招聘",
    "51job.com": "前程无忧",
    "linkedin.com": "LinkedIn Jobs",
    "lagou.com": "拉勾",
}


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def source_name(url: str) -> str:
    host = urlparse(url).netloc.lower()
    for domain, name in PORTAL_DOMAINS.items():
        if domain in host:
            return name
    return "公开招聘页面"


def find_company(text: str, companies: list[dict]):
    lower = text.lower()
    for company in companies:
        names = [company["name"], *company.get("aliases", [])]
        if any(name.lower() in lower for name in names):
            return company
    return None


def extract_salary(text: str) -> str:
    match = re.search(r"\d+(?:\.\d+)?\s*[-~—–]\s*\d+(?:\.\d+)?\s*[kK](?:[·x×*]\s*\d+薪)?", text)
    return re.sub(r"\s+", "", match.group(0)) if match else "面议"


def clean_search_title(title: str, company: dict) -> str:
    cleaned = title
    for name in [company["name"], *company.get("aliases", [])]:
        cleaned = re.sub(re.escape(name), "", cleaned, flags=re.IGNORECASE)
    cleaned = re.sub(r"重庆|招聘信息|招聘|职位|工作机会|【|】|\[|\]", "", cleaned)
    cleaned = re.sub(r"\s*[-_|｜]\s*", " ", cleaned)
    cleaned = " ".join(cleaned.split()).strip(" -|｜")
    return cleaned[:80] or "职位详情"


def is_relevant(text: str, preferences: dict) -> bool:
    lower = text.lower()
    targets = [str(x).lower() for x in preferences.get("target_keywords", [])]
    return any(keyword in lower for keyword in targets)


def serper_search(query: str, api_key: str, num: int = 10) -> list[dict]:
    request = urllib.request.Request(
        "https://google.serper.dev/search",
        data=json.dumps({"q": query, "num": num, "gl": "cn", "hl": "zh-cn"}).encode("utf-8"),
        headers={"X-API-KEY": api_key, "Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(request, timeout=30) as response:
        payload = json.loads(response.read().decode("utf-8"))
    return payload.get("organic", [])


def discovery_queries(companies: list[dict]) -> list[str]:
    role_query = '("经营分析" OR "运营分析" OR "数据分析" OR "BI" OR "数据治理" OR "市场研究" OR "目标管理" OR "商业分析")'
    queries = []
    for index in range(0, len(companies), 3):
        names = " OR ".join(f'"{c["name"]}"' for c in companies[index:index + 3])
        queries.append(f'重庆 招聘 ({names}) {role_query}')
    for domain in PORTAL_DOMAINS:
        queries.append(f'site:{domain} 重庆 {role_query} 招聘')
    return queries


def discover_with_serper(api_key: str, companies: list[dict], preferences: dict) -> list[dict]:
    discovered = []
    seen_urls = set()
    for query in discovery_queries(companies):
        try:
            results = serper_search(query, api_key)
        except Exception as exc:
            print(f"warning: search failed for {query!r}: {exc}", file=sys.stderr)
            continue
        for hit in results:
            url = str(hit.get("link", ""))
            if not url or url in seen_urls:
                continue
            seen_urls.add(url)
            # Serper may return a recruiting portal's list/search page.  Such a
            # URL is useful for discovery but must never be exposed as a JD link.
            if not is_direct_job_url(url):
                continue
            title = str(hit.get("title", ""))
            snippet = str(hit.get("snippet", ""))
            text = f"{title} {snippet}"
            if "重庆" not in text or not is_relevant(text, preferences):
                continue
            company = find_company(text, companies)
            if not company:
                continue
            cleaned_title = clean_search_title(title, company)
            if is_pseudo_job_title(cleaned_title):
                continue
            raw = {
                "company": company["name"],
                "company_tier": company["tier"],
                "title": cleaned_title,
                "location": "重庆",
                "salary": extract_salary(text),
                "experience": "未注明",
                "education": "未注明",
                "description": snippet,
                "source": source_name(url),
                "source_url": url,
                "published_at": str(hit.get("date", "")),
                "discovered_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
            }
            discovered.append(normalize_search_result(raw))
    return discovered


def build_feed(seed_path: Path, preferences_path: Path, companies_path: Path, use_search: bool = True) -> list[dict]:
    preferences = load_json(preferences_path)
    companies = load_json(companies_path)
    seed_raw = load_json(seed_path)
    jobs = [normalize_search_result(item) for item in seed_raw]

    api_key = os.getenv("SERPER_API_KEY")
    if use_search and api_key:
        jobs.extend(discover_with_serper(api_key, companies, preferences))

    jobs = dedupe_jobs(jobs)
    scored = []
    for job in jobs:
        result = score_job(job, preferences)
        job.update(result)
        scored.append(job)
    return scored


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", default=str(ROOT / "public/data/jobs.json"))
    parser.add_argument("--seed", default=str(ROOT / "data/seed_jobs.json"))
    parser.add_argument("--no-search", action="store_true", help="Use curated fixture data only")
    args = parser.parse_args()

    jobs = build_feed(
        Path(args.seed),
        ROOT / "config/preferences.json",
        ROOT / "config/target_companies.json",
        use_search=not args.no_search,
    )
    publish_jobs(jobs, args.output)
    visible = sum(1 for j in jobs if j.get("score", 0) >= 60)
    print(f"published {len(jobs)} jobs ({visible} visible) -> {args.output}")


if __name__ == "__main__":
    main()
