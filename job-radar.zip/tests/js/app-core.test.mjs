import test from 'node:test';
import assert from 'node:assert/strict';
import { dashboardStats, filterJobs, sortJobs } from '../../public/js/app-core.mjs';

const jobs = [
  { id:'1', company:'赛力斯集团', title:'经营分析', score:92, tier:'直接投', salary_min_k:20, salary_max_k:30, company_tier:'S', published_at:'2026-08-19', sources:[{name:'猎聘'}] },
  { id:'2', company:'龙湖集团', title:'市场研究岗', score:80, tier:'值得冲', salary_min_k:10, salary_max_k:13, company_tier:'S', published_at:'2026-08-18', sources:[{name:'猎聘'}] },
  { id:'3', company:'某公司', title:'数据录入', score:55, tier:'隐藏', salary_min_k:8, salary_max_k:9, company_tier:'C', published_at:'2026-08-19', sources:[{name:'智联招聘'}] }
];

test('filter hides disliked and below-60 jobs by default', () => {
  const statuses = {'2':'disliked'};
  const result = filterJobs(jobs, {}, statuses);
  assert.deepEqual(result.map(j => j.id), ['1']);
});

test('filter supports text search and minimum salary', () => {
  const result = filterJobs(jobs, { query:'龙湖', showHidden:true, minSalary:10 }, {});
  assert.deepEqual(result.map(j => j.id), ['2']);
});

test('sortJobs supports score and published date', () => {
  assert.deepEqual(sortJobs(jobs, 'score').map(j => j.id), ['1','2','3']);
  assert.deepEqual(sortJobs(jobs, 'published').map(j => j.id), ['1','3','2']);
});

test('dashboardStats counts today, high-match, worth-shot and favorites', () => {
  const stats = dashboardStats(jobs, {'2':'favorite'}, '2026-08-19T09:00:00+08:00');
  assert.deepEqual(stats, {today:2, highMatch:1, worthShot:1, favorites:1});
});
