import json
from pathlib import Path

from radar.discovery import dedupe_jobs, normalize_search_result, publish_jobs, stable_job_id


def test_stable_job_id_ignores_source_but_uses_company_title_location():
    a = stable_job_id("赛力斯集团", "销售运营-目标管理", "重庆")
    b = stable_job_id("赛力斯集团", "销售运营-目标管理", "重庆")
    c = stable_job_id("赛力斯集团", "数据分析产品工程师", "重庆")
    assert a == b
    assert a != c


def test_normalize_search_result_standardizes_fields():
    raw = {
        "company": "赛力斯集团 ",
        "title": " 销售运营-目标管理 ",
        "location": "重庆",
        "salary": "20-50k·14薪",
        "experience": "3年以上",
        "education": "本科",
        "description": "负责目标拆解和经营分析",
        "source": "猎聘",
        "source_url": "https://example.com/job/1",
        "published_at": "2026-08-15",
        "company_tier": "S",
    }
    job = normalize_search_result(raw)
    assert job["company"] == "赛力斯集团"
    assert job["title"] == "销售运营-目标管理"
    assert job["location"] == "重庆"
    assert job["id"] == stable_job_id("赛力斯集团", "销售运营-目标管理", "重庆")
    assert job["sources"][0]["name"] == "猎聘"


def test_dedupe_jobs_merges_sources_and_keeps_richer_description():
    base = {
        "company": "赛力斯集团",
        "title": "销售运营-目标管理",
        "location": "重庆",
        "salary": "20-50k·14薪",
        "experience": "3年以上",
        "education": "本科",
        "description": "目标管理",
        "source": "猎聘",
        "source_url": "https://example.com/a",
        "published_at": "2026-08-15",
        "company_tier": "S",
    }
    richer = dict(base)
    richer.update(
        source="官方招聘",
        source_url="https://example.com/b",
        description="负责销售目标制定与拆解、周月度目标体系、进度监控和经营分析。",
    )
    result = dedupe_jobs([normalize_search_result(base), normalize_search_result(richer)])
    assert len(result) == 1
    assert len(result[0]["sources"]) == 2
    assert "进度监控" in result[0]["description"]


def test_publish_jobs_writes_envelope_sorted_by_score(tmp_path: Path):
    jobs = [
        {"id": "b", "score": 70, "title": "B"},
        {"id": "a", "score": 90, "title": "A"},
    ]
    output = tmp_path / "jobs.json"
    publish_jobs(jobs, output, updated_at="2026-08-19T08:00:00+08:00")
    payload = json.loads(output.read_text(encoding="utf-8"))
    assert payload["updated_at"] == "2026-08-19T08:00:00+08:00"
    assert payload["count"] == 2
    assert [job["id"] for job in payload["jobs"]] == ["a", "b"]
