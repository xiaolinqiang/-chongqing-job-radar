import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PUBLIC = ROOT / 'public'


def test_manifest_is_installable_standalone_pwa():
    manifest = json.loads((PUBLIC / 'manifest.webmanifest').read_text(encoding='utf-8'))
    assert manifest['name'] == '重庆职位雷达'
    assert manifest['display'] == 'standalone'
    assert manifest['start_url'] == './'
    assert manifest['scope'] == './'
    sizes = {icon['sizes'] for icon in manifest['icons']}
    assert '192x192' in sizes
    assert '512x512' in sizes


def test_service_worker_caches_shell_and_job_feed():
    sw = (PUBLIC / 'sw.js').read_text(encoding='utf-8')
    for asset in ['./', './css/app.css', './js/app.mjs', './data/jobs.json']:
        assert asset in sw
    assert 'fetch' in sw


def test_ios_meta_and_icons_are_present():
    html = (PUBLIC / 'index.html').read_text(encoding='utf-8')
    assert 'apple-mobile-web-app-capable' in html
    assert 'apple-touch-icon' in html
    assert 'manifest.webmanifest' in html
    assert (PUBLIC / 'icons/icon-192.png').exists()
    assert (PUBLIC / 'icons/icon-512.png').exists()
    assert (PUBLIC / 'icons/apple-touch-icon.png').exists()
