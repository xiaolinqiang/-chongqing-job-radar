from radar.scoring import normalize_salary, recommendation_tier, score_job


def test_normalize_salary_parses_k_range_and_months():
    assert normalize_salary("15-25k·15薪") == (15, 25, 15)


def test_normalize_salary_handles_single_monthly_value():
    assert normalize_salary("12K") == (12, 12, None)


def test_recommendation_tiers_follow_spec():
    assert recommendation_tier(91) == "直接投"
    assert recommendation_tier(80) == "值得冲"
    assert recommendation_tier(65) == "观察"
    assert recommendation_tier(59) == "隐藏"


def test_score_rewards_big_company_relevant_role_and_salary_upgrade():
    preferences = {
        "current_salary_k": 9,
        "minimum_salary_k": 12,
        "preferred_salary_k": 15,
        "target_keywords": ["经营分析", "运营分析", "预算", "目标管理", "数据分析"],
        "exclude_keywords": ["销售代表", "电话销售", "招商主管"],
        "allow_management": False,
        "allow_sales": False,
    }
    job = {
        "company": "赛力斯集团",
        "company_tier": "S",
        "title": "销售运营-目标管理",
        "location": "重庆",
        "salary": "20-50k·14薪",
        "description": "负责销售目标制定与拆解、月度周度目标体系、进度监控和经营分析，不带团队。",
        "is_outsourcing": False,
    }

    result = score_job(job, preferences)

    assert result["score"] >= 85
    assert result["tier"] == "直接投"
    assert any("平台" in reason for reason in result["reasons"])
    assert any("薪资" in reason for reason in result["reasons"])


def test_score_penalizes_sales_management_and_low_salary():
    preferences = {
        "current_salary_k": 9,
        "minimum_salary_k": 12,
        "preferred_salary_k": 15,
        "target_keywords": ["经营分析", "运营分析", "数据分析"],
        "exclude_keywords": ["销售代表", "电话销售", "招商主管"],
        "allow_management": False,
        "allow_sales": False,
    }
    job = {
        "company": "某小型公司",
        "company_tier": "C",
        "title": "销售招商主管",
        "location": "重庆",
        "salary": "8-10k",
        "description": "负责销售拓展、团队管理、完成销售KPI。",
        "is_outsourcing": False,
    }

    result = score_job(job, preferences)

    assert result["score"] < 60
    assert result["tier"] == "隐藏"
    assert any("销售" in gap or "管理" in gap for gap in result["gaps"])
