from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_index_has_required_app_landmarks():
    html = (ROOT / 'public/index.html').read_text(encoding='utf-8')
    for marker in ['data-view="today"', 'data-view="jobs"', 'data-view="applications"', 'data-view="settings"', 'id="job-list"', 'id="bottom-nav"']:
        assert marker in html
    assert '/css/app.css' in html
    assert '/js/app.mjs' in html
    assert 'class="pipeline-select"' in html


def test_ui_assets_exist():
    assert (ROOT / 'public/css/app.css').exists()
    assert (ROOT / 'public/js/app.mjs').exists()
