from scripts import update_jobs


COMPANIES = [
    {"name": "长安汽车", "aliases": ["重庆长安汽车", "长安"], "tier": "S"},
]
PREFERENCES = {"target_keywords": ["数据分析", "BI", "经营分析"]}


def test_discovery_skips_portal_search_page_even_when_title_matches(monkeypatch):
    monkeypatch.setattr(
        update_jobs,
        "discovery_queries",
        lambda companies: ["test"],
    )
    monkeypatch.setattr(
        update_jobs,
        "serper_search",
        lambda query, api_key: [
            {
                "title": "长安汽车 BI工程师招聘信息",
                "link": "https://m.liepin.com/zpBIgongchengshi/",
                "snippet": "重庆 BI工程师 数据分析 20-35k",
            }
        ],
    )
    assert update_jobs.discover_with_serper("key", COMPANIES, PREFERENCES) == []


def test_discovery_skips_article_or_aggregation_title(monkeypatch):
    monkeypatch.setattr(update_jobs, "discovery_queries", lambda companies: ["test"])
    monkeypatch.setattr(
        update_jobs,
        "serper_search",
        lambda query, api_key: [
            {
                "title": "长安汽车 数据分析岗位怎么样",
                "link": "https://www.liepin.com/job/1984718675.shtml",
                "snippet": "重庆 数据分析 15-25k",
            }
        ],
    )
    assert update_jobs.discover_with_serper("key", COMPANIES, PREFERENCES) == []


def test_discovery_keeps_direct_job_detail_link(monkeypatch):
    monkeypatch.setattr(update_jobs, "discovery_queries", lambda companies: ["test"])
    monkeypatch.setattr(
        update_jobs,
        "serper_search",
        lambda query, api_key: [
            {
                "title": "长安汽车招聘 数据分析产品工程师（A107542） - 猎聘",
                "link": "https://www.liepin.com/job/1984718675.shtml",
                "snippet": "重庆 数据分析 15-25k 本科 5-10年",
                "date": "2026-08-19",
            }
        ],
    )
    jobs = update_jobs.discover_with_serper("key", COMPANIES, PREFERENCES)
    assert len(jobs) == 1
    assert jobs[0]["title"] == "数据分析产品工程师（A107542） 猎聘"
    assert jobs[0]["sources"][0]["url"] == "https://www.liepin.com/job/1984718675.shtml"
