from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_update_workflow_runs_daily_in_shanghai_and_can_be_manual():
    text = (ROOT / '.github/workflows/update-jobs.yml').read_text(encoding='utf-8')
    assert "timezone: 'Asia/Shanghai'" in text or 'timezone: "Asia/Shanghai"' in text
    assert "cron: '15 8 * * *'" in text
    assert 'workflow_dispatch:' in text
    assert 'SERPER_API_KEY' in text
    assert 'python scripts/update_jobs.py' in text


def test_workflow_deploys_public_folder_to_pages():
    text = (ROOT / '.github/workflows/update-jobs.yml').read_text(encoding='utf-8')
    assert 'actions/upload-pages-artifact@v5' in text
    assert 'path: public' in text
    assert 'actions/deploy-pages@v4' in text


def test_local_server_and_requirements_exist():
    assert (ROOT / 'scripts/serve.py').exists()
    req = (ROOT / 'requirements.txt').read_text(encoding='utf-8')
    assert 'pytest' in req
